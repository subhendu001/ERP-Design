import pymysql
conn=pymysql.connect(host='localhost',user='root',password='',db='erp')
a=conn.cursor()

sql= ("SELECT SicNo FROM student")							#query to fetch sic of all the faculty in form of list of list
a.execute(sql);
s=a.fetchall();


sql= "SELECT SicNo FROM faculty"							#query to fetch sic of all the faculty in form of list of list
a.execute(sql);
f=a.fetchall();

sql= "SELECT SicNo FROM staff"								#query to fetch sic of all the faculty in form of list of list
a.execute(sql);
st=a.fetchall();

fl=len(f);
sl=len(s);
stl=len(st);

k='';


def faculty_sic():
	print('THE FACULTIES DETAILS ARE');
	for i in range(0,int(fl)):								#fetch the sic of individual faculty which is a list from the list of lists
		temp=str(f[i]);										#convert the list to string with all quotaion
		templen=len(temp);									#length of each faculty sic string with all quotaion
		for j in range (0,templen):
			if(temp[j]==','):
				print(temp[2:j-1]);							#the isolated string obtained

				
				
def student_sic():
	print('THE STUDENTS DETAILS ARE');						#fetch the sic of individual faculty which is a list from the list of lists
	for i in range(0,int(sl)):								#convert the list to string with all quotaion
		temp=str(s[i]);										#length of each faculty sic string with all quotaion
		templen=len(temp);
		for j in range (0,templen):
			if(temp[j]==","):
				print(temp[2:j-1]);							#the isolated string obtained

				
				

def staff_sic():
	print('THE STAFFS DETAILS ARE');						#fetch the sic of individual faculty which is a list from the list of lists
	for i in range(0,int(stl)):								#convert the list to string with all quotaion
		temp=str(st[i]);									#length of each faculty sic string with all quotaion
		templen=len(temp);
		for j in range (0,templen):
			if(temp[j]==","):
				print(temp[2:j-1]);	
				
faculty_sic();
student_sic();
staff_sic();