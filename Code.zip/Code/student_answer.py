import pymysql

conn=pymysql.connect(host='localhost',user='root',password='',db='erp')
a=conn.cursor();


def create_temp_student_answer_table():
	sql=("CREATE TABLE  `student_answer` (QNO_sa INT NOT NULL ,ans INT NOT NULL)");
	a.execute(sql);
	for i in range(0,10):
		k=0;
		j=i+1;
		a.execute("INSERT INTO `student_answer` VALUES (%s,%s)",[j,k]);

		

#inserting the answers of the student in the temporary table for evaluation
def answer(qno):
	ans=0;
	while(int(ans) < 1 or int(ans) > 4):
		ans=input("\nENTER THE CORRECT OPTION\n");
		if(ans!=''):
			#print('THE 1ST LOOP');
			check=ans.isnumeric();
			if(check==True):
				if(int(ans) >0 and int(ans) < 5):
					#print('THE SECOND LOOP');
					a.execute("UPDATE student_answer SET ans=%s WHERE QNO_sa=%s",[ans,qno]);
					#print(ans);
					#print('1QUERY EXECUTED')
					break;
				else:
					print('\nYOU HAVE ENTERED THE WRONG OPTION');
					print('PLEASE TRY AGAIN\n');
			else:
				print('YOU HAVE ENTERED A STRING\n');
				print('TRY AGAIN\n');
				ans=0;
		if(ans ==''):
			#print('THE INVENTED LOOP')
			ans=0;
			a.execute("UPDATE student_answer SET ans=%s WHERE QNO_sa=%s",[ans,qno]);
			#print(ans);
			#print('2QUERY EXECUTED')
			break;
	

	

#fetching all the options to evaluate the total mark of the student
def evaluate(sic):
	urmark=0;
	list=[];
	for i in range(0,10):
		sql=("SELECT ans FROM student_answer where QNO_sa=%s");
		values=i+1;
		a.execute(sql,values);
		data=a.fetchall();
		s=str(data);
		#print(s[2]);
		list.append(s[2]);
	
	sql=("SELECT * FROM answer");								#fetching the actual answer from the database
	a.execute(sql);												#all answers in the form of list of lists
	actual_answer=a.fetchall();									
	laa=len(actual_answer);										#total number of answers or total number of list in the list of lists(in my case its 10) 
	
	print("\n\n");
	print("COMPARE YOUR ANSWERS\n")
	for i in range(0,laa):										#fetching each minor list from the major list
		temp=actual_answer[i];
		print("student_answer :",list[i]);
		print("actual answer  :",temp[1]);
		if(int(list[i])==int(temp[1])):
			urmark=urmark+1;
		print("\n\n\n");
		
	
	
	print("YOUR MARK IS ",urmark);
	storing(sic,urmark);
	
	
	

def drop():
	sql=("DROP TABLE student_answer");
	a.execute(sql);
	
def storing(sic,urmark):	
	sql=("INSERT INTO student_mark_store VALUES (%s,%s)");
	values=(sic,urmark);
	a.execute(sql,values);

def seehistory(sic):
	sql=("SELECT * FROM student_mark_store where SicNo=%s");	#fetching the actual answer from the database
	value=sic;
	a.execute(sql,value);												#all answers in the form of list of lists
	actual_answer=a.fetchall();									
	laa=len(actual_answer);
	
	print("TIMES --------> MARKS")
	for i in range(0,laa):										#fetching each minor list from the major list
		temp=actual_answer[i];
		if(i<9):
			t=i+1;
			print("%s -------------> %s"%(t,temp[1]));		#showing both the column separately 
		else:
			print("%s ------------> %s"%(t+1,temp[1]));	