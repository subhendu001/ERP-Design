import pymysql
conn=pymysql.connect(host='localhost',user='root',password='',db='erp')
a=conn.cursor()


#ask for the sic for his or her fee payment
def paying_sic():
	name1=input('ENTER THE SIC NUMBER OF THE STUDENT\n');
	a.execute("SELECT SicNo FROM student");
	data=a.fetchall();
	l=len(data);
	flag=0;
	for i in range(0,l):
		temp1=data[i];
		temp=str(temp1[0]);
		if(temp==name1):
			flag=1;
			break;
	if(flag==1):
		fetchdata(name1);
	else:
		print('YOU HAVE ENTERED THE WRONG SIC');
		print('PLEASE TRY AGAIN');
		paying_sic();


#all the data of the entered sic is fetched from the student_profile table
def fetchdata(name1):
	sql= "SELECT * FROM bookissued WHERE SicNo=%s "
	values = (name1)
	a.execute(sql,values)
	data = a.fetchone();
	#print(data);
	isolation(data,name1);

	
def isolation(data,sic):
	print('THE BOOKS FOR SIC ',sic);
	l=len(data);
	for i in range(1,l):
		print("BOOK %d ----->%s"%(i,data[i]));


#paying_sic()