import pymysql;

conn=pymysql.connect(host='localhost',user='root',password='',db='erp')
a=conn.cursor()

#THE WORKING MODULES
import role_checking;
#import all_members_sic;



import student_profile;
import student_attendance;
import student_mark;
import student_fees;
import online_exam;
import student_answer;
import phone_student;
import email_student;


import faculty_profile;
import attendance_modify;
import marks_modify;
import phone_faculty;
import email_faculty;


import staff_profile;
import staff_modify_fee;
import email_staff;
import phone_staff;
import staff_book_issue_checking;




#CALL FOR CHECKING THE ROLL IN THE STARTING STATE TO SHOW THE APPROPRIATE OPTION
sic=role_checking.input_for_rolechecking()
role=role_checking.checking(sic);


#PRINTS THE ROLL OF THE MEMBER
#print(role);

#INITIAL PERMISSION FOR THE STARTING OF THE LOOP
perm='yes';

if(role=='student'):
	while(perm == "yes"):
	
		#FOR ENTERING INTO THE WHILE LOOP TO KNOW THE USER DECISION
		perm='star';
		
		
		nic=student_profile.forname(sic);
		print('\nWHAT YOU WANT TO CHECK %s'%(nic));
		
		
		
		#WHAT A STUDENT CAN ACESS OR MODIFY
		print("1 PROFILE DETAILS");
		print("2 ATTENDANCE");
		print("3 INTERNAL MARKS");
		print("4 TOTAL DUES");
		print("5 APPEAR ONLINE EXAM");
		print("6 SEE ALL YOUR ONLINE EXAM RESULTS");
		print("7 WANT TO MODIFY YOUR EMAIL OR PHONE NUMBER");
		
		
		#INITIAL CONDITION FOR GETTING ENTERED INTO THE LOOP
		ch=0;
		while(ch < 1 or ch > 8):
			ch=int(input("\nENTER YOUR CHOICE\n"));
			if(ch >=1 and ch < 8):
				break;
			else:
				print('\nYOU HAVE ENTERED THE WRONG OPTION');
				print('PLEASE TRY AGAIN\n');
		
		
		
		
		if(ch==1):
			print('\nYOUR PROFILE DETAILS ARE');
			student_profile.fetch_your_info(sic);
			
		if(ch==2):
			print('\nYOUR ATTENDANCE OF ALL THE CLASSES ARE');
			student_attendance.getsic(sic);
			
		if(ch==3):
			print('\nYOUR INTERNAL MARKS ARE');
			student_mark.getsic(sic);
			
			
		if(ch==4):
			print('\nYOUR REMAINING DUES IS');
			student_fees.getsic(sic);
			
			
		if(ch==5):
			student_answer.drop();
			student_answer.create_temp_student_answer_table();
			online_exam.exam(sic);
			online_exam.ev(sic);
		
		if(ch==6):
			student_answer.seehistory(sic);


		chp=5;	
			
		if(ch==7):
			print('ENTER 1 TO CHANGE YOUR PHONE NUMBER && ENTER 2 TO CHANGE YOUR EMAIL ID\n');
			while(int(chp) < 1 or int(chp) > 2):
				chp=input("\nENTER YOUR CHOICE\n");
				str_chk=chp.isnumeric();
				if(str_chk==True):
					if(int(chp) >0 and int(chp) <3):
						if(int(chp)==1):
							print('YOU CAN UPDATE YOUR PHONE NUMBER\n');
							phone_student.askph(sic);
							break;
						if(int(chp)==2):
							print('YOU CAN UPDATE YOUR EMAIL ID\n');
							email_student.askem(sic);
							break;
					else:
						print('\nYOU HAVE ENTERED THE WRONG OPTION');
						print('PLEASE TRY AGAIN\n');
				else:
					chp=5;
					print('ENTER A NUMBER\n');
		
		
		
		#THE LOOP WHICH EXIST WITH NO AND ASK ONCE MORE FOR WRONG INPUT
		while(perm != 'yes' or perm !='no'):
			print("\nDO YOU WANT TO CHECK ANYTHNG MORE");
			perm=input('WRITE yes TO CHECK ONCE MORE AND no TO LOGOUT\n')
			if(perm == 'yes'):
				break;
			if(perm == 'no'):
				print('\n\nTHANK YOU !!!');
				exit(0);
			else:
				print('\nYOU HAVE ENTERED THE WRONG OPTION');
				print('PLEASE TRY AGAIN\n');
				
				
				
				
				
				
								
				
if(role=='faculty'):
	while(perm == "yes"):
	
		#FOR ENTERING INTO THE WHILE LOOP TO KNOW THE USER DECISION
		perm='star';
		
		
		nic=faculty_profile.forname(sic);
		print('\nWHAT YOU WANT TO CHECK %s'%(nic));
		
		
		
		#WHAT A FACULTY CAN ACESS OR MODIFY
		print("1 PROFILE DETAILS");
		print("2 TODAY'S IN TIME");
		print("3 TODAY'S OUT TIME");
		print("4 INTERNAL MARKS OF YOUR STUDENTS");
		print("5 ATTENDANCE OF YOUR STUDENTS");
		print("6 WANT TO MODIFY YOUR EMAIL OR PHONE NUMBER");
		
		
		#INITIAL CONDITION FOR GETTING ENTERED INTO THE LOOP
		ch=0;
		while(ch < 1 or ch > 8):
			ch=int(input("\nENTER YOUR CHOICE\n"));
			if(ch >=1 and ch < 7):
				break;
			else:
				print('\nYOU HAVE ENTERED THE WRONG OPTION');
				print('PLEASE TRY AGAIN\n');
		
		
		
		
		if(ch==1):
			print('\nYOUR PROFILE DETAILS ARE');
			faculty_profile.fetch_your_info(sic);
			
		if(ch==2):
			print("\nTODAY'S YOUR IN TIME TO THE COLLEGE");
			sql=("SELECT InTime FROM faculty WHERE Sicno=%s");
			a.execute(sql,sic);
			d=a.fetchone();
			print(d[0]);
			
			
		
		if(ch==3):
			print("\nTODAY'S YOUR OUT TIME TO THE COLLEGE");
			sql=("SELECT OutTime FROM faculty WHERE Sicno=%s");
			a.execute(sql,sic);
			d=a.fetchone();
			print(d[0]);
			
		if(ch==4):
			marks_modify.enter(sic);

		if(ch==5):
			attendance_modify.enter(sic);

			

		chp=5;	
			
		if(ch==6):
			print('ENTER 1 TO CHANGE YOUR PHONE NUMBER && ENTER 2 TO CHANGE YOUR EMAIL ID\n');
			while(int(chp) < 1 or int(chp) > 2):
				chp=input("\nENTER YOUR CHOICE\n");
				str_chk=chp.isnumeric();
				if(str_chk==True):
					if(int(chp) >0 and int(chp) <3):
						if(int(chp)==1):
							print('YOU CAN UPDATE YOUR PHONE NUMBER\n');
							phone_faculty.askph(sic);
							break;
						if(int(chp)==2):
							print('YOU CAN UPDATE YOUR EMAIL ID\n');
							email_faculty.askem(sic);
							break;
					else:
						print('\nYOU HAVE ENTERED THE WRONG OPTION');
						print('PLEASE TRY AGAIN\n');
				else:
					chp=5;
					print('ENTER A NUMBER\n');

			

		#THE LOOP WHICH EXIST WITH NO AND ASK ONCE MORE FOR WRONG INPUT
		while(perm != 'yes' or perm !='no'):
			print("\nDO YOU WANT TO CHECK ANYTHNG MORE");
			perm=input('WRITE yes TO CHECK ONCE MORE AND no TO LOGOUT\n')
			if(perm == 'yes'):
				break;
			if(perm == 'no'):
				print('\n\nTHANK YOU !!!');
				exit(0);
			else:
				print('\nYOU HAVE ENTERED THE WRONG OPTION');
				print('PLEASE TRY AGAIN\n');
				


				
				
if(role=='staff'):
	if(sic=='cc123667'):
		while(perm == "yes"):
		
			#FOR ENTERING INTO THE WHILE LOOP TO KNOW THE USER DECISION
			perm='star';
			
			
			nic=staff_profile.forname(sic);
			print('\nWHAT YOU WANT TO CHECK %s'%(nic));
			
			
			
			#WHAT A STAFF CAN ACESS OR MODIFY
			print("1 PROFILE DETAILS");
			print("2 TODAY'S IN TIME");
			print("3 TODAY'S OUT TIME");
			print("4 RECIEVE THE PAYMENT OF ANY STUDENT");
			print("5 WANT TO MODIFY YOUR EMAIL OR PHONE NUMBER");
			
			
			#INITIAL CONDITION FOR GETTING ENTERED INTO THE LOOP
			ch=0;
			while(ch < 1 or ch > 8):
				ch=int(input("\nENTER YOUR CHOICE\n"));
				if(ch >=1 and ch < 7):
					break;
				else:
					print('\nYOU HAVE ENTERED THE WRONG OPTION');
					print('PLEASE TRY AGAIN\n');
			
			
			
			
			if(ch==1):
				print('\nYOUR PROFILE DETAILS ARE');
				staff_profile.fetch_your_info(sic);
				
			if(ch==2):
				print("\nTODAY'S YOUR IN TIME TO THE COLLEGE");
				sql=("SELECT InTime FROM staff WHERE Sicno=%s");
				a.execute(sql,sic);
				d=a.fetchone();
				print(d[0]);
				
				
			
			if(ch==3):
				print("\nTODAY'S YOUR OUT TIME TO THE COLLEGE");
				sql=("SELECT OutTime FROM staff WHERE Sicno=%s");
				a.execute(sql,sic);
				d=a.fetchone();
				print(d[0]);			

			
			if(ch==4):
				staff_modify_fee.paying_sic();
			
			

			chp=5;	
				
			if(ch==5):
				print('ENTER 1 TO CHANGE YOUR PHONE NUMBER && ENTER 2 TO CHANGE YOUR EMAIL ID\n');
				while(int(chp) < 1 or int(chp) > 2):
					chp=input("\nENTER YOUR CHOICE\n");
					str_chk=chp.isnumeric();
					if(str_chk==True):
						if(int(chp) >0 and int(chp) <3):
							if(int(chp)==1):
								print('YOU CAN UPDATE YOUR PHONE NUMBER\n');
								phone_staff.askph(sic);
								break;
							if(int(chp)==2):
								print('YOU CAN UPDATE YOUR EMAIL ID\n');
								email_staff.askem(sic);
								break;
						else:
							print('\nYOU HAVE ENTERED THE WRONG OPTION');
							print('PLEASE TRY AGAIN\n');
					else:
						chp=5;
						print('ENTER A NUMBER\n');
			
			
			#THE LOOP WHICH EXIST WITH NO AND ASK ONCE MORE FOR WRONG INPUT
			while(perm != 'yes' or perm !='no'):
				print("\nDO YOU WANT TO CHECK ANYTHNG MORE");
				perm=input('WRITE yes TO CHECK ONCE MORE AND no TO LOGOUT\n')
				if(perm == 'yes'):
					break;
				if(perm == 'no'):
					print('\n\nTHANK YOU !!!');
					exit(0);
				else:
					print('\nYOU HAVE ENTERED THE WRONG OPTION');
					print('PLEASE TRY AGAIN\n');
					
					
					
	if(sic=='lb123434'):
		while(perm == "yes"):
		
			#FOR ENTERING INTO THE WHILE LOOP TO KNOW THE USER DECISION
			perm='star';
			
			
			nic=staff_profile.forname(sic);
			print('\nWHAT YOU WANT TO CHECK %s'%(nic));
			
			
			
			#WHAT A STAFF CAN ACESS OR MODIFY
			print("1 PROFILE DETAILS");
			print("2 TODAY'S IN TIME");
			print("3 TODAY'S OUT TIME");
			print("4 SEE THE BOOK ISSUED BY ANY STUDENT");
			print("5 WANT TO MODIFY YOUR EMAIL OR PHONE NUMBER");
			
			
			#INITIAL CONDITION FOR GETTING ENTERED INTO THE LOOP
			ch=0;
			while(ch < 1 or ch > 8):
				ch=int(input("\nENTER YOUR CHOICE\n"));
				if(ch >=1 and ch < 7):
					break;
				else:
					print('\nYOU HAVE ENTERED THE WRONG OPTION');
					print('PLEASE TRY AGAIN\n');
			
			
			
			
			if(ch==1):
				print('\nYOUR PROFILE DETAILS ARE');
				staff_profile.fetch_your_info(sic);
				
			if(ch==2):
				print("\nTODAY'S YOUR IN TIME TO THE COLLEGE");
				sql=("SELECT InTime FROM staff WHERE Sicno=%s");
				a.execute(sql,sic);
				d=a.fetchone();
				print(d[0]);
				
				
			
			if(ch==3):
				print("\nTODAY'S YOUR OUT TIME TO THE COLLEGE");
				sql=("SELECT OutTime FROM staff WHERE Sicno=%s");
				a.execute(sql,sic);
				d=a.fetchone();
				print(d[0]);			
			
			if(ch==4):
				print("\nYOU CAN CHECK THE BOOKS ISSUED BY ANY STUDENT FROM THE LIBRARY\n")
				staff_book_issue_checking.paying_sic();
			
			

			chp=5;	
				
			if(ch==5):
				print('ENTER 1 TO CHANGE YOUR PHONE NUMBER && ENTER 2 TO CHANGE YOUR EMAIL ID\n');
				while(int(chp) < 1 or int(chp) > 2):
					chp=input("\nENTER YOUR CHOICE\n");
					str_chk=chp.isnumeric();
					if(str_chk==True):
						if(int(chp) >0 and int(chp) <3):
							if(int(chp)==1):
								print('YOU CAN UPDATE YOUR PHONE NUMBER\n');
								phone_staff.askph(sic);
								break;
							if(int(chp)==2):
								print('YOU CAN UPDATE YOUR EMAIL ID\n');
								email_staff.askem(sic);
								break;
						else:
							print('\nYOU HAVE ENTERED THE WRONG OPTION');
							print('PLEASE TRY AGAIN\n');
					else:
						chp=5;
						print('ENTER A NUMBER\n');				
				
				
				
			#THE LOOP WHICH EXIST WITH NO AND ASK ONCE MORE FOR WRONG INPUT
			while(perm != 'yes' or perm !='no'):
				print("\nDO YOU WANT TO CHECK ANYTHNG MORE");
				perm=input('WRITE yes TO CHECK ONCE MORE AND no TO LOGOUT\n')
				if(perm == 'yes'):
					break;
				if(perm == 'no'):
					print('\n\nTHANK YOU !!!');
					exit(0);
				else:
					print('\nYOU HAVE ENTERED THE WRONG OPTION');
					print('PLEASE TRY AGAIN\n');

					
					
if(role !='faculty' and role!='student' and role!='staff'):
	print('YOU HAVE ENTERED A WRONG SIC NUMBER\n');