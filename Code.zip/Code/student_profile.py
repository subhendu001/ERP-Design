import pymysql

def fetch_your_info(sic):
	conn=pymysql.connect(host='localhost',user='root',password='',db='erp')
	a=conn.cursor()
	name1=sic;
	sql= "SELECT * FROM student WHERE SicNo=%s "
	values = (name1)
	a.execute(sql,values);
	data = a.fetchone();
	you(data);
	
def forname(sic):
	conn=pymysql.connect(host='localhost',user='root',password='',db='erp')
	a=conn.cursor()
	name1=sic;
	sql= "SELECT Name FROM student WHERE SicNo=%s "
	values = (name1)
	a.execute(sql,values);
	data = a.fetchone();
	nic=data[0];
	return(nic);


def you(data):	
	print("RegdNo-",data[0])
	print("PhnNo-",data[1])
	print("SicNo-",data[2])
	#print("Name-",data[3])
	print("Email-",data[4])