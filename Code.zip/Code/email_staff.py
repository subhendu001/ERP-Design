import pymysql;
conn=pymysql.connect(host='localhost',user='root',password='',db='erp')
a=conn.cursor()

def askem(sic):
	name1=sic;
	s=input('ENTER THE UPDATED EMAIL ID\n');
	sym='@';
	if(sym in s):
		updation(s,name1);
		print('EMAIL ID IS UPDATED\n');
	else:
		print('ENTER A VALID EMAIL ID\n');
		askem(sic);

		
def updation(s,name1):
	a.execute("UPDATE staff SET Email=%s WHERE SicNo=%s",[s,name1]);