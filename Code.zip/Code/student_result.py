import pymysql

conn=pymysql.connect(host='localhost',user='root',password='',db='erp')
a=conn.cursor();


def evaluation():
	
	sql=("SELECT * FROM answer");								#fetching the actual answer from the database
	a.execute(sql);												#all answers in the form of list of lists
	actual_answer=a.fetchall();									
	laa=len(actual_answer)										#total number of answers or total number of list in the list of lists(in my case its 10) 
	
	
	
	
	
	
	
	for i in range(0,laa):										#fetching each minor list from the major list
		temp=actual_answer[i];
		if(i<9):
			print("%s -------------> %s"%(temp[0],temp[1]));	#showing both the column separately 
		else:
			print("%s ------------> %s"%(temp[0],temp[1]));		#showing both the column separately
	