import pymysql

conn=pymysql.connect(host='localhost',user='root',password='',db='erp')
a=conn.cursor()

def enter(sic):
	name2=sic;
	sql= "SELECT subjectId FROM faculty WHERE SicNo=%s "
	values =(name2)
	a.execute(sql,values)
	data1=a.fetchone();
	st=str(data1);
	stk=st[1];
	a.execute("select subject.sicno,subject.subjectname,marks.marks from subject,marks where (subject.SicNo=marks.SicNo) and (subject.SubjectId=%s and marks.SubjectId=%s) ",[stk,stk]);
	data = a.fetchall();
	#print(data)
	showing(data,stk);

	
	
def showing(data,stk1):	
	length=len(data);
	perm='star'
	
	print("SicNo"+"          "+"Marks")
	for i in range(0,length):
		temp=data[i];
		print("%s         %s"%(temp[0],temp[2]));


		
	while(perm != 'yes' or perm !='no'):
		print("\nDO YOU WANNA TO MODIFY THE MARKS OF ANY STUDENT");
		perm=input('WRITE yes TO MODIFY OTHERWISE WRITE no\n')
		if(perm == 'yes'):
			modify_marks(data,stk1);
			break;
		if(perm == 'no'):
			break;
		else:
			print('PLEASE TRY AGAIN\n');		
		

	
		
def modify_marks(data,stk2):
	pre=0;
	name3=input("ENTER THE SIC OF THE STUDENT WHOSE MARKS YOU WANNA MODIFY :");
	length=len(data);
	for i in range(0,length):
		temp=data[i];
		if(name3==str(temp[0])):
			pre=1;
			break;
			
	if(pre==1):
		print("THE CURRENT MARKS IS :%s" %(temp[2]));
		modification(name3,stk2);
	else:
		print("THE ENTERED SIC IS WRONG PLEASE TRY AGAIN\n");
		modify_marks(data,stk2)

		
		

def modification(name4,stk3):
	attend=input("Enter the new marks");
	a.execute("UPDATE marks SET marks=%s WHERE (SicNo=%s and subjectId=%s)",[attend,name4,stk3]);