import pymysql
conn=pymysql.connect(host='localhost',user='root',password='',db='erp')
a=conn.cursor()


#ask for the sic for his or her fee payment
def paying_sic():
	name1 = input('ENTER THE SIC NUMBER OF THE STUDENT\n');
	sql=('SELECT SicNo from student');
	a.execute(sql);
	data=a.fetchall();
	ldata=len(data);
	flag=0;
	for i in range(0,ldata):
		temp1=data[i];
		temp=temp1[0];
		if(name1==temp):
			flag=1;
			break;
	
	if(flag==1):
		fetchdata(name1);
	else:
		print("THAT'S NOT THE SIC OF A STUDENT\n");
		print('ENTER THE VALID SIC NUMBER\n');
		paying_sic();


#all the data of the entered sic is fetched from the student_profile table
def fetchdata(name1):
	sql= "SELECT * FROM student WHERE SicNo=%s "
	values = (name1)
	a.execute(sql,values)
	data = a.fetchone();
	reduction(name1,data)

def reduction(name1,data):
	print("Fees-",data[5]);
	n=input("Enter the amount you want to pay");
	check=n.isnumeric();
	#print(check);
	if(check==True):
		if(int(n)>0):
			s=data[5]-int(n);
			updation(s,name1);
		else:
			print('YOU HAVE ENTERED A NEGETIVE AMMOUNT\n');
			reduction(name1,data);
	else:
		print('ENTER A VALID AMMOUNT\n');
		reduction(name1,data);


def updation(s,name1):
	a.execute("UPDATE student SET fees=%s WHERE SicNo=%s",[s,name1])
	sql= "SELECT * FROM student WHERE SicNo=%s "
	values = (name1)
	a.execute(sql,values)
	data = a.fetchone();
	print("Fees-",data[5]);
