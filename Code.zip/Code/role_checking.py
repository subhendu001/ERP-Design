import pymysql
conn=pymysql.connect(host='localhost',user='root',password='',db='erp')
a=conn.cursor()





sql= ("SELECT SicNo FROM student")								#query to fetch sic of all the faculty in form of list of list
a.execute(sql);
s=a.fetchall();


sql= "SELECT SicNo FROM faculty"								#query to fetch sic of all the faculty in form of list of list
a.execute(sql);
f=a.fetchall();

sql= ("SELECT SicNO FROM staff");								#query to fetch sic of all the staff in form of list of list
a.execute(sql);
st=a.fetchall();


fl=len(f);
sl=len(s);
stl=len(st);


k='';





			
def input_for_rolechecking():
	sic=input("ENTER YOUR SIC NUMBER TO LOG IN\n");
	return(sic);



	
def checking(sic):	
	sc=student_check(sic);										#call for checking the student and get the return as 0 or 1
	fc=faculty_check(sic);										#call for checking the faculty and get the return as 0 or 1
	stc=staff_check(sic);
	
	
	
	if(fc==1):
		return('faculty');
	if(sc==1):
		return('student');
	if(stc==1):
		return('staff');
	if(sc!=1 and fc!=1 and st!=1):								#if the entered sic is neither a student nor a faculty
		return("YOU ENTERED A WRONG SIC NUMBER TRY AGAIN\n");
			
			
			


			
			
def faculty_check(sic):
	check=0;
	for i in range(0,int(fl)):		
		temp=str(f[i]);
		templen=len(temp);	
		for j in range (0,templen):		
			if(temp[j]==','):
				k=temp[2:j-1];
				if(k == sic):
					check=1;									#the value becomes 1 if the entered sic match with one of the faculty in the list
					break;
	return(check);												#the value of check is returned to where it is called
	
	
	
	
	
	
def student_check(sic):
	chk=0;
	for i in range(0,int(sl)):		
		temp=str(s[i]);
		templen=len(temp);
		for j in range (0,templen):
			if(temp[j]==','):
				k=temp[2:j-1];
				if(k == sic):
					chk=1;										#the value becomes 1 if the entered sic match with one of the faculty in the list
					break;	
	return(chk);												#the value of check is returned to where it is called
	
	
	
	
	
	
	
	
	
def staff_check(sic):
	ck=0;
	for i in range(0,int(stl)):		
		temp=str(st[i]);
		templen=len(temp);
		for j in range (0,templen):
			if(temp[j]==','):
				k=temp[2:j-1];
				if(k == sic):
					ck=1;										#the value becomes 1 if the entered sic match with one of the staff in the list
					break;
	return(ck);													#the value of check is returned to where it is called