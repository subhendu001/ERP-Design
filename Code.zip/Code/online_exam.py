import pymysql;
import student_answer;
import student_result;
conn=pymysql.connect(host='localhost',user='root',password='',db='erp');


a=conn.cursor();
b=conn.cursor();


def exam(sic):
	sqlq=("SELECT Q FROM question;");								#select all question from the question table
	a.execute(sqlq);				 			
	dataq=a.fetchall();												#dataq contains all the questions as a list of list format
	lq=len(dataq);							


	v=0;															#for indexing
	p='yes'
	
	
	
	print("ONLINE EXAM\n");
	if(p=='yes'):
		for i in range(0,lq):										#lq is the total number of questions present
			
			temq=str(dataq[i]);										#converting a single list of dataq to string with all quotions(''), with it
			lqtem=len(temq);										#length of each individual question with all quotion
			
			print("QUESTION NUMBER %d"%(i+1));
			for j in range(0,lqtem):								#0th index of the question string to index in which ? mark is present i.e scanning all the letters ofthe string
				if(temq[j]=='?'):
					tempq=temq[2:j+1];
					print(tempq);
					break;											#at the end of these a single question can be printed without quotion
			
			
			v=v+1													#giving the option number as an argument in the query
			
			
			
			#SHOWING THE FIRST OPTION FOR THE RESPECTED QUESTION
			print("OPTIONS")
			sqlo=("SELECT OP1 FROM  `option` WHERE QNO_O=%s ")		#query for selecting first option where q no is according the value of v
			b.execute(sqlo,v);
			datao=b.fetchall();										#fetch a list only (not list of lists); 
			
			#print(datao);
			
			
			temo=str(datao);										#converting the list with all list default notation 
			lotem=len(temo);										#length of the converted string
			
			
			for k in range(0,lotem):								#isolation starts	
				if(temo[k]==","):
					tempo=temo[3:k-1];
					print("1      ",tempo);									#isolation ends
					break;											#for preventing the loop in going forword



			
			
			
			
			#SHOWING THE SECOND OPTION FOR THE RESPECTED QUESTION
			sqlo=("SELECT OP2 FROM  `option` WHERE QNO_O=%s ")		#query for selecting first option where q no is according the value of v
			b.execute(sqlo,v);
			datao=b.fetchall();										#fetch a list only (not list of lists); 
			
			#print(datao);
			
			
			temo=str(datao);										#converting the list with all list default notation 
			lotem=len(temo);										#length of the converted string
			
			
			for k in range(0,lotem):								#isolation starts	
				if(temo[k]==","):
					tempo=temo[3:k-1];
					print("2      ",tempo);						#isolation ends
					break;											#for preventing the loop in going forword
			
			
			
			
			
			
			
			#SHOWING THE THIRD OPTION FOR THE RESPECTED QUESTION
			sqlo=("SELECT OP3 FROM  `option` WHERE QNO_O=%s ")		#query for selecting first option where q no is according the value of v
			b.execute(sqlo,v);
			datao=b.fetchall();										#fetch a list only (not list of lists); 
			
			#print(datao);
			
			
			temo=str(datao);										#converting the list with all list default notation 
			lotem=len(temo);										#length of the converted string
			
			
			for k in range(0,lotem):								#isolation starts	
				if(temo[k]==","):
					tempo=temo[3:k-1];
					print("3      ",tempo);						#isolation ends
					break;											#for preventing the loop in going forword

					
			


			#SHOWING THE FOURTH OPTION FOR THE RESPECTED QUESTION
			sqlo=("SELECT OP4 FROM  `option` WHERE QNO_O=%s ")		#query for selecting first option where q no is according the value of v
			b.execute(sqlo,v);
			datao=b.fetchall();										#fetch a list only (not list of lists); 
			
			#print(datao);
			
			
			temo=str(datao);										#converting the list with all list default notation 
			lotem=len(temo);										#length of the converted string
			
			
			for k in range(0,lotem):								#isolation starts	
				if(temo[k]==","):
					tempo=temo[3:k-1];
					print("4      ",tempo);							#isolation ends	
					break;											#for preventing the loop in going forword	
			
		
			
			
			
			
			
			
			
			student_answer.answer(i+1);
			
			
			
			
			
			
			
			
			

				
			p='no';													#for if condition to be executed or to ask to see the next question
			if(p != 'yes' and i < lq-1):
				p=input("ENTER 'yes' TO SEE THE NEXT QUESTION AND 'no' TO EXIT FROM THE EXAM\n");
				print("\n\n\n\n");
				if(p=='no'):
					break;
				if(p!='yes' and p!='no'):
					for r in range(0,3):					
						print("%d TIMES REMAINING\n"%(3-(r+1)));
						p=input('ENTER yes TO SEE THE NEXT QUESTION\n');
						print("\n\n");
						if(p=='yes'):
							break;


							
							
														



def ev(sic):
	student_answer.evaluate(sic);	