import pymysql

conn=pymysql.connect(host='localhost',user='root',password='',db='erp')
a=conn.cursor()


def getsic(sic):
	name1=sic;
	a.execute("select subjectname,marks from subject,marks where (subject.SicNo=%s and marks.SicNo= %s) and subject.SubjectId=marks.SubjectId ",[name1,name1])
	printmark();
	
def printmark():
	data = a.fetchall()
	ldata=len(data);
	for i in range(0,ldata):
		temp=data[i];
		print("%s -> %s"%(temp[0],temp[1]));