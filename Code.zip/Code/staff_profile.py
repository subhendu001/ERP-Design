import pymysql

def fetch_your_info(sic):
	conn=pymysql.connect(host='localhost',user='root',password='',db='erp')
	a=conn.cursor()
	name1=sic;
	sql= "SELECT * FROM staff WHERE SicNo=%s "
	values = (name1)
	a.execute(sql,values);
	data = a.fetchone();
	you(data);

	
def you(data):	
	print("SicNo-",data[4])
	#print("Name-",data[2])
	print("Dept ID-",data[3]);
	print("Email-",data[1])
	print("PhnNo-",data[0])
	
	
def forname(sic):
	conn=pymysql.connect(host='localhost',user='root',password='',db='erp')
	a=conn.cursor()
	name1=sic;
	sql= "SELECT * FROM staff WHERE SicNo=%s "
	values = (name1)
	a.execute(sql,values);
	data = a.fetchone();
	nic=name(data);
	return(nic);

def name(data):
	Name=data[2];
	return(Name);