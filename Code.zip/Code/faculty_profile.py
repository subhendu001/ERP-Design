import pymysql

def fetch_your_info(sic):
	conn=pymysql.connect(host='localhost',user='root',password='',db='erp')
	a=conn.cursor()
	name1=sic;
	sql= "SELECT * FROM faculty WHERE SicNo=%s "
	values = (name1)
	a.execute(sql,values);
	data = a.fetchone();
	you(data);
	
def forname(sic):
	conn=pymysql.connect(host='localhost',user='root',password='',db='erp')
	a=conn.cursor()
	name1=sic;
	sql= "SELECT * FROM faculty WHERE SicNo=%s "
	values = (name1)
	a.execute(sql,values);
	data = a.fetchone();
	nic=name(data);
	return(nic);

def name(data):
	Name=data[3];
	return(Name);
	
def you(data):	
	print("SicNo-",data[5])
	#print("Name-",data[3])
	print("Dept ID-",data[4]);
	print("Email-",data[2])
	print("PhnNo-",data[1]);
