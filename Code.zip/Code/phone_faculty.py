import pymysql;
conn=pymysql.connect(host='localhost',user='root',password='',db='erp')
a=conn.cursor()

def askph(sic):
	name1=sic;
	s=input('ENTER THE UPDATED PHONE NUMBER\n');
	tv=s.isnumeric();
	if(tv ==True):
		l=len(s);
		if(l==10):
			updation(s,name1)
			print('THE PHONE NUMBER IS UPDATED');
		else:
			print('YOU HAVE ENTERED A WRONG NUMBER\n');
			askph(sic);
	else:
		print('YOU HAVE ENTERED A WRONG NUMBER\n');
		askph(sic);		

		
def updation(s,name1):
	a.execute("UPDATE faculty SET Mobile=%s WHERE SicNo=%s",[s,name1])	