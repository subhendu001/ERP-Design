import pymysql

conn=pymysql.connect(host='localhost',user='root',password='',db='erp')
a=conn.cursor()



def getsic(sic):
	name1=sic;
	sql= "SELECT * FROM student WHERE SicNo=%s "
	values =(name1);
	a.execute(sql,values)
	print_dues()
	
def print_dues():
	data = a.fetchone();
	print("Dues-",data[5]);

